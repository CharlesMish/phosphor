import { create } from "zustand";
import {
  OSCILLATOR_SAMPLE_TARGET,
  cycleMorphSamples,
  synth,
  type SynthParams,
} from "./engine";
import {
  cloneWave,
  generatePreset,
  invertWave,
  mirrorWave,
  normalizeWave,
  smoothWave,
  wavesDiffer,
  type WavePreset,
} from "./waveform";
import {
  INITIAL_SPACE_SEED,
  SPACE_DEFAULT_SECONDS,
  buildSpaceView,
  clampSpaceSeconds,
  cloneContour,
  contoursDiffer,
  generateSpaceContour,
  type SpacePreset,
} from "./space";
import {
  DRIVE_DEFAULT_AMOUNT,
  DRIVE_DEFAULT_SAFE,
  DRIVE_SAFE_MAX_AMOUNT,
  clampDriveAmount,
  cloneTransfer,
  generateDrivePreset,
  identifyDrivePreset,
  transfersDiffer,
  type DrivePreset,
} from "./drive";
import {
  CHORUS_DEFAULT_PERIOD,
  chorusCurvesDiffer,
  cloneChorusCurve,
  generateChorusPreset,
  identifyChorusPreset,
  type ChorusPreset,
} from "./chorus";
import {
  DEFAULT_MOTION_BEATS,
  DEFAULT_MOTION_BPM,
  DEFAULT_MOTION_MODE,
  MOTION_BEAT_LENGTHS,
  clampMotionBpm,
  cloneMotionPath,
  clampMotionValue,
  createDefaultMotionPath,
  generateMotionPreset,
  motionPathsDiffer,
  sampleMotionPath,
  type MotionBeats,
  type MotionMode,
  type MotionPreset,
} from "./motion";
import {
  DEFAULT_MOTION_ROUTES,
  clampMotionEndpoint,
  hasPlayableMotionRoute,
  mapMotionRoute,
  type MotionRoutes,
  type MotionRouteId,
  type MotionNumericRouteId,
  type MotionRouteEndpoint,
} from "./motion-routing";

export type { WavePreset, SpacePreset, DrivePreset, ChorusPreset };

export type EditorDomain = "cycle" | "motion" | "drive" | "chorus" | "space";

const HISTORY_LIMIT = 32;
export const INITIAL_SPACE_MIX = 0.38;

type SpaceSnap = {
  contour: number[];
  seed: number;
  preset: SpacePreset | "custom";
  metal: boolean;
};

type DriveSnap = {
  curve: number[];
  preset: DrivePreset | "custom";
};

type ChorusSnap = {
  curve: number[];
  preset: ChorusPreset | "custom";
};

type SynthState = {
  domain: EditorDomain;
  samples: number[];
  preset: WavePreset | "custom";
  attack: number;
  release: number;
  volume: number;
  trimDb: number;
  cutoff: number;
  octave: number;
  activeNotes: number[];
  audioReady: boolean;
  hasDrawn: boolean;
  slotA: number[] | null;
  slotB: number[] | null;
  morph: number;
  morphLive: boolean;
  motionPath: number[];
  motionPlaying: boolean;
  motionProgress: number;
  motionRunId: number;
  motionBpm: number;
  motionBeats: MotionBeats;
  motionMode: MotionMode;
  motionRoutes: MotionRoutes;
  motionPast: number[][];
  motionFuture: number[][];
  past: number[][];
  future: number[][];
  driveCurve: number[];
  drivePreset: DrivePreset | "custom";
  driveAmount: number;
  driveSafe: boolean;
  driveHasDrawn: boolean;
  drivePast: DriveSnap[];
  driveFuture: DriveSnap[];
  chorusCurve: number[];
  chorusPreset: ChorusPreset | "custom";
  chorusPeriod: number;
  chorusMix: number;
  chorusPast: ChorusSnap[];
  chorusFuture: ChorusSnap[];
  spaceContour: number[];
  spaceView: number[];
  spaceSeed: number;
  spacePreset: SpacePreset | "custom";
  /** Metal modes are processing state, independent of whether the contour is still the preset shape. */
  spaceMetal: boolean;
  spaceMix: number;
  spaceSeconds: number;
  spaceHasDrawn: boolean;
  spacePast: SpaceSnap[];
  spaceFuture: SpaceSnap[];
};

export type SavedSessionPatch = {
  domain: EditorDomain;
  samples: number[];
  preset: WavePreset | "custom";
  hasDrawn: boolean;
  slotA: number[] | null;
  slotB: number[] | null;
  morph: number;
  morphLive: boolean;
  attack: number;
  release: number;
  cutoff: number;
  volume: number;
  trimDb: number;
  octave: number;
  driveCurve: number[];
  drivePreset: DrivePreset | "custom";
  driveAmount: number;
  driveSafe: boolean;
  driveHasDrawn: boolean;
  chorusCurve: number[];
  chorusPreset: ChorusPreset | "custom";
  chorusPeriod: number;
  chorusMix: number;
  spaceContour: number[];
  spaceSeed: number;
  spacePreset: SpacePreset | "custom";
  spaceMetal: boolean;
  spaceMix: number;
  spaceSeconds: number;
  spaceHasDrawn: boolean;
  motionPath: number[];
  motionBpm: number;
  motionBeats: MotionBeats;
  motionMode: MotionMode;
  motionRoutes: MotionRoutes;
};

type SynthActions = {
  setDomain: (domain: EditorDomain) => void;
  setLiveSamples: (samples: number[], immediate?: boolean) => void;
  commitSamples: (samples: number[], preset?: WavePreset | "custom") => void;
  finishGesture: (before: number[], after: number[]) => void;
  applyPreset: (preset: WavePreset) => void;
  resetWave: () => void;
  smooth: () => void;
  normalize: () => void;
  invert: () => void;
  randomize: () => void;
  mirror: () => void;
  captureA: () => void;
  captureB: () => void;
  swapSlots: () => void;
  setMorph: (t: number, immediate?: boolean) => void;
  auditionMotion: (t: number, immediate?: boolean) => void;
  setLiveMotionPath: (path: number[]) => void;
  applyMotionPreset: (preset: MotionPreset) => void;
  finishMotionGesture: (before: number[], after: number[]) => void;
  playMotion: () => void;
  stopMotion: () => void;
  setMotionBpm: (bpm: number) => void;
  setMotionBeats: (beats: MotionBeats) => void;
  setMotionMode: (mode: MotionMode) => void;
  setMotionRouteEnabled: (route: MotionRouteId, enabled: boolean) => void;
  setMotionRouteEndpoint: (route: MotionNumericRouteId, endpoint: MotionRouteEndpoint, value: number) => void;
  setMotionPlaybackPosition: (
    t: number,
    progress: number,
    complete: boolean,
    runId: number,
  ) => void;
  undo: () => void;
  redo: () => void;
  setLiveDrive: (curve: number[]) => void;
  finishDriveGesture: (before: number[], after: number[]) => void;
  applyDrivePreset: (preset: DrivePreset) => void;
  setDriveAmount: (amount: number) => void;
  setDriveSafe: (safe: boolean) => void;
  setLiveChorus: (curve: number[]) => void;
  finishChorusGesture: (before: number[], after: number[]) => void;
  applyChorusPreset: (preset: ChorusPreset) => void;
  setChorusPeriod: (period: number) => void;
  setChorusMix: (mix: number) => void;
  setLiveContour: (contour: number[]) => void;
  finishSpaceGesture: (before: number[], after: number[]) => void;
  applySpacePreset: (preset: SpacePreset) => void;
  scatterSpace: () => void;
  setSpaceMix: (mix: number) => void;
  setSpaceLength: (seconds: number) => void;
  commitSpaceLength: (seconds: number) => void;
  setParam: (key: keyof SynthParams, value: number) => void;
  setOctave: (octave: number) => void;
  setActiveNotes: (notes: number[]) => void;
  setAudioReady: (ready: boolean) => void;
  markDrawn: () => void;
  markSpaceDrawn: () => void;
  /** Replace the saved instrument state. Clears histories and leaves Motion stopped. */
  replaceSavedSession: (patch: SavedSessionPatch) => void;
};

const initialSamples = generatePreset("sine");
const initialMotionPath = createDefaultMotionPath();
const initialDriveCurve = generateDrivePreset("identity");
const initialChorusCurve = generateChorusPreset("sine");
const initialContour = generateSpaceContour("room");
const initialSeed = INITIAL_SPACE_SEED;

function pushPast(past: number[][], snapshot: number[]): number[][] {
  const next = [...past, cloneWave(snapshot)];
  if (next.length > HISTORY_LIMIT) next.splice(0, next.length - HISTORY_LIMIT);
  return next;
}

function pushMotionPast(past: number[][], snapshot: number[]): number[][] {
  const next = [...past, cloneMotionPath(snapshot)];
  if (next.length > HISTORY_LIMIT) next.splice(0, next.length - HISTORY_LIMIT);
  return next;
}

function pushDrivePast(past: DriveSnap[], snap: DriveSnap): DriveSnap[] {
  const next = [
    ...past,
    { curve: cloneTransfer(snap.curve), preset: snap.preset },
  ];
  if (next.length > HISTORY_LIMIT) next.splice(0, next.length - HISTORY_LIMIT);
  return next;
}

function pushChorusPast(past: ChorusSnap[], snap: ChorusSnap): ChorusSnap[] {
  const next = [
    ...past,
    { curve: cloneChorusCurve(snap.curve), preset: snap.preset },
  ];
  if (next.length > HISTORY_LIMIT) next.splice(0, next.length - HISTORY_LIMIT);
  return next;
}

function pushSpacePast(past: SpaceSnap[], snap: SpaceSnap): SpaceSnap[] {
  const next = [
    ...past,
    {
      contour: cloneContour(snap.contour),
      seed: snap.seed,
      preset: snap.preset,
      metal: snap.metal,
    },
  ];
  if (next.length > HISTORY_LIMIT) next.splice(0, next.length - HISTORY_LIMIT);
  return next;
}

function morphSamples(slotA: number[], slotB: number[], t: number): number[] {
  return cycleMorphSamples(slotA, slotB, t);
}

function applySpace(contour: number[], seed: number, metal: boolean, seconds: number) {
  synth.setSpace(contour, seed, metal, seconds);
}

function applyDrive(
  curve: number[],
  amount: number,
  safe: boolean,
  smoothAmount = false,
) {
  synth.setDriveState(curve, amount, safe, smoothAmount);
}

export const useSynthStore = create<SynthState & SynthActions>((set, get) => {
  type MorphSource = "manual" | "motion-drawing" | "motion-playback";

  const applyMorphPosition = (
    t: number,
    source: MorphSource,
    immediate = false,
    motionState: Partial<SynthState> = {},
  ) => {
    const { slotA, slotB, morphLive, samples: prev } = get();
    if (!slotA || !slotB) return false;
    const u = Math.min(1, Math.max(0, t));
    const samples = morphSamples(slotA, slotB, u);
    const recordCycleHistory = source === "manual";
    const reengage =
      recordCycleHistory && !morphLive &&
      wavesDiffer(normalizeWave(prev, OSCILLATOR_SAMPLE_TARGET), samples);
    set({
      morph: u,
      samples,
      preset: "custom",
      hasDrawn: true,
      morphLive: true,
      ...(source !== "motion-playback" ? { motionPlaying: false } : {}),
      ...(reengage ? { past: pushPast(get().past, prev), future: [] } : {}),
      ...motionState,
    });
    synth.setCycleMorph(slotA, slotB, u, immediate);
    return true;
  };

  // One sampled value drives every enabled destination. Motion frames never
  // invoke manual setters or create authored history entries.
  const applyMotionValue = (
    value: number,
    immediate: boolean,
    motionState: Partial<SynthState>,
  ) => {
    const state = get();
    const routes = state.motionRoutes;
    if (!hasPlayableMotionRoute(routes, Boolean(state.slotA && state.slotB))) return false;
    const u = clampMotionValue(value);
    const next: Partial<SynthState> = { ...motionState };
    const cycle = routes.cycle.enabled && state.slotA && state.slotB;
    if (cycle) {
      const morph = routes.cycle.inverted ? 1 - u : u;
      Object.assign(next, {
        morph,
        samples: morphSamples(state.slotA!, state.slotB!, morph),
        preset: "custom",
        hasDrawn: true,
        morphLive: true,
      });
    }
    for (const id of ["driveAmount", "chorusMix", "spaceMix"] as const) {
      if (routes[id].enabled) next[id] = mapMotionRoute(id, routes[id], u);
    }
    set(next);
    if (cycle) synth.setCycleMorph(state.slotA!, state.slotB!, next.morph!, immediate);
    if (next.driveAmount !== undefined && next.driveAmount !== state.driveAmount) {
      applyDrive(state.driveCurve, next.driveAmount, state.driveSafe);
    }
    if (next.chorusMix !== undefined && next.chorusMix !== state.chorusMix) synth.setChorusMix(next.chorusMix);
    if (next.spaceMix !== undefined && next.spaceMix !== state.spaceMix) synth.setSpaceMix(next.spaceMix);
    return true;
  };

  const stopForManualRoute = (route: MotionNumericRouteId) => {
    if (get().motionPlaying && get().motionRoutes[route].enabled) set({ motionPlaying: false });
  };

  return {
  domain: "cycle",
  samples: initialSamples,
  preset: "sine",
  attack: 0.04,
  release: 0.28,
  volume: 0.72,
  trimDb: 0,
  cutoff: 1,
  octave: 0,
  activeNotes: [],
  audioReady: false,
  hasDrawn: false,
  slotA: null,
  slotB: null,
  morph: 0,
  morphLive: false,
  motionPath: initialMotionPath,
  motionRoutes: DEFAULT_MOTION_ROUTES,
  motionPlaying: false,
  motionProgress: 0,
  motionRunId: 0,
  motionBpm: DEFAULT_MOTION_BPM,
  motionBeats: DEFAULT_MOTION_BEATS,
  motionMode: DEFAULT_MOTION_MODE,
  motionPast: [],
  motionFuture: [],
  past: [],
  future: [],
  driveCurve: initialDriveCurve,
  drivePreset: "identity",
  driveAmount: DRIVE_DEFAULT_AMOUNT,
  driveSafe: DRIVE_DEFAULT_SAFE,
  driveHasDrawn: false,
  drivePast: [],
  driveFuture: [],
  chorusCurve: initialChorusCurve,
  chorusPreset: "sine",
  chorusPeriod: CHORUS_DEFAULT_PERIOD,
  chorusMix: 0,
  chorusPast: [],
  chorusFuture: [],
  spaceContour: initialContour,
  spaceView: buildSpaceView(initialContour, initialSeed),
  spaceSeed: initialSeed,
  spacePreset: "room",
  spaceMetal: false,
  spaceMix: INITIAL_SPACE_MIX,
  spaceSeconds: SPACE_DEFAULT_SECONDS,
  spaceHasDrawn: false,
  spacePast: [],
  spaceFuture: [],

  setDomain: (domain) => {
    set({ domain });
    synth.unlock();
  },

  setLiveDrive: (curve) => {
    set({
      driveCurve: curve,
      drivePreset: "custom",
      driveHasDrawn: true,
    });
    // Keep pointer rendering/store state immediate while coalescing the costly
    // WaveShaper table assignment to the same cadence as CYCLE drawing.
    synth.setDriveCurve(curve, false);
  },

  finishDriveGesture: (before, after) => {
    const { drivePast, driveAmount, driveSafe } = get();
    const changed = transfersDiffer(before, after);
    set({
      driveCurve: after,
      drivePreset: "custom",
      driveHasDrawn: true,
      ...(changed
        ? {
            drivePast: pushDrivePast(drivePast, {
              curve: before,
              preset: identifyDrivePreset(before),
            }),
            driveFuture: [],
          }
        : {}),
    });
    applyDrive(after, driveAmount, driveSafe);
  },

  applyDrivePreset: (preset) => {
    const { driveCurve, drivePreset, drivePast, driveAmount, driveSafe } = get();
    const next = generateDrivePreset(preset);
    if (!transfersDiffer(driveCurve, next) && drivePreset === preset) {
      set({ drivePreset: preset, driveHasDrawn: true });
      applyDrive(next, driveAmount, driveSafe);
      return;
    }
    set({
      driveCurve: next,
      drivePreset: preset,
      driveHasDrawn: true,
      drivePast: pushDrivePast(drivePast, {
        curve: driveCurve,
        preset: drivePreset,
      }),
      driveFuture: [],
    });
    applyDrive(next, driveAmount, driveSafe);
  },

  setDriveAmount: (amount) => {
    stopForManualRoute("driveAmount");
    const { driveCurve, driveSafe } = get();
    const clamped = clampDriveAmount(amount);
    const next = driveSafe
      ? Math.min(DRIVE_SAFE_MAX_AMOUNT, clamped)
      : clamped;
    set({ driveAmount: next });
    applyDrive(driveCurve, next, driveSafe);
    synth.unlock();
  },

  setDriveSafe: (safe) => {
    stopForManualRoute("driveAmount");
    const state = get();
    const nextAmount = safe
      ? Math.min(DRIVE_SAFE_MAX_AMOUNT, state.driveAmount)
      : state.driveAmount;
    const smoothClamp =
      safe && !state.driveSafe && state.driveAmount > DRIVE_SAFE_MAX_AMOUNT;
    set({ driveSafe: safe, driveAmount: nextAmount });
    applyDrive(state.driveCurve, nextAmount, safe, smoothClamp);
    synth.unlock();
  },

  setLiveChorus: (curve) => {
    set({ chorusCurve: curve, chorusPreset: "custom" });
    synth.setChorusCurve(curve);
  },

  finishChorusGesture: (before, after) => {
    const changed = chorusCurvesDiffer(before, after);
    set({
      chorusCurve: after,
      chorusPreset: changed ? "custom" : identifyChorusPreset(before),
      ...(changed
        ? {
            chorusPast: pushChorusPast(get().chorusPast, {
              curve: before,
              preset: identifyChorusPreset(before),
            }),
            chorusFuture: [],
          }
        : {}),
    });
    synth.setChorusCurve(after);
  },

  applyChorusPreset: (preset) => {
    const { chorusCurve, chorusPreset, chorusPast } = get();
    const next = generateChorusPreset(preset);
    if (!chorusCurvesDiffer(chorusCurve, next) && chorusPreset === preset) {
      synth.setChorusCurve(next);
      return;
    }
    set({
      chorusCurve: next,
      chorusPreset: preset,
      chorusPast: pushChorusPast(chorusPast, {
        curve: chorusCurve,
        preset: chorusPreset,
      }),
      chorusFuture: [],
    });
    synth.setChorusCurve(next);
  },

  setChorusPeriod: (period) => {
    const next = Math.min(4, Math.max(0.25, period));
    set({ chorusPeriod: next });
    synth.setChorusPeriod(next);
  },

  setChorusMix: (mix) => {
    stopForManualRoute("chorusMix");
    const next = Math.min(1, Math.max(0, mix));
    set({ chorusMix: next });
    synth.setChorusMix(next);
    synth.unlock();
  },

  setLiveSamples: (samples, immediate = false) => {
    set({ samples, preset: "custom", morphLive: false, motionPlaying: false });
    synth.setWaveform(samples, immediate);
  },

  commitSamples: (samples, preset = "custom") => {
    const prev = get().samples;
    if (!wavesDiffer(prev, samples)) {
      set({ samples, preset, hasDrawn: true, morphLive: false, motionPlaying: false });
      synth.setWaveform(samples, true);
      return;
    }
    set({
      samples,
      preset,
      hasDrawn: true,
      morphLive: false,
      motionPlaying: false,
      past: pushPast(get().past, prev),
      future: [],
    });
    synth.setWaveform(samples, true);
  },

  finishGesture: (before, after) => {
    const changed = wavesDiffer(before, after);
    set({
      samples: after,
      preset: "custom",
      hasDrawn: true,
      morphLive: false,
      motionPlaying: false,
      ...(changed ? { past: pushPast(get().past, before), future: [] } : {}),
    });
    synth.setWaveform(after, true);
  },

  applyPreset: (preset) => {
    get().commitSamples(generatePreset(preset), preset);
  },
  resetWave: () => {
    get().commitSamples(generatePreset("sine"), "sine");
  },
  smooth: () => {
    get().commitSamples(smoothWave(get().samples, 1));
  },
  normalize: () => {
    get().commitSamples(normalizeWave(get().samples, 0.92));
  },
  invert: () => {
    get().commitSamples(invertWave(get().samples));
  },
  randomize: () => {
    get().commitSamples(generatePreset("wild"), "wild");
  },
  mirror: () => {
    get().commitSamples(mirrorWave(get().samples));
  },

  captureA: () => {
    const samples = cloneWave(get().samples);
    set({
      slotA: samples,
      morph: 0,
      hasDrawn: true,
      morphLive: Boolean(get().slotB),
      motionPlaying: false,
    });
  },
  captureB: () => {
    const samples = cloneWave(get().samples);
    set({
      slotB: samples,
      morph: 1,
      hasDrawn: true,
      morphLive: Boolean(get().slotA),
      motionPlaying: false,
    });
  },
  swapSlots: () => {
    const { slotA, slotB, morph, motionRoutes } = get();
    set({
      slotA: slotB ? cloneWave(slotB) : null,
      slotB: slotA ? cloneWave(slotA) : null,
      morph: 1 - morph,
      // Swapping Cycle endpoints must not invert the other effects' motion.
      motionRoutes: {
        ...motionRoutes,
        cycle: { ...motionRoutes.cycle, inverted: !motionRoutes.cycle.inverted },
      },
      motionPlaying: false,
    });
  },
  setMorph: (t, immediate = false) => {
    applyMorphPosition(t, "manual", immediate);
  },

  auditionMotion: (t, immediate = false) => {
    applyMotionValue(t, immediate, { motionPlaying: false });
  },

  setLiveMotionPath: (path) => {
    set({ motionPath: path });
  },

  applyMotionPreset: (preset) => {
    const { motionPath, motionPast } = get();
    const next = generateMotionPreset(preset);
    set({
      motionPlaying: false,
      motionProgress: 0,
      motionPath: next,
      ...(motionPathsDiffer(motionPath, next)
        ? { motionPast: pushMotionPast(motionPast, motionPath), motionFuture: [] }
        : {}),
    });
  },

  finishMotionGesture: (before, after) => {
    const changed = motionPathsDiffer(before, after);
    set({
      motionPath: after,
      ...(changed
        ? { motionPast: pushMotionPast(get().motionPast, before), motionFuture: [] }
        : {}),
    });
  },

  playMotion: () => {
    const { slotA, slotB, motionPath, motionRunId, motionRoutes } = get();
    if (!hasPlayableMotionRoute(motionRoutes, Boolean(slotA && slotB))) return;
    synth.unlock();
    const nextRunId = motionRunId + 1;
    applyMotionValue(sampleMotionPath(motionPath, 0), true, {
      motionPlaying: true,
      motionProgress: 0,
      motionRunId: nextRunId,
    });
  },

  stopMotion: () => set({ motionPlaying: false }),

  setMotionBpm: (bpm) => {
    const next = clampMotionBpm(bpm);
    if (next === get().motionBpm) return;
    get().stopMotion();
    set({ motionBpm: next });
  },
  setMotionBeats: (beats) => {
    if (MOTION_BEAT_LENGTHS.includes(beats)) set({ motionBeats: beats });
  },
  setMotionMode: (mode) => set({ motionMode: mode }),

  setMotionRouteEnabled: (route, enabled) => {
    const routes = get().motionRoutes;
    set({ motionPlaying: false, motionRoutes: { ...routes, [route]: { ...routes[route], enabled } } });
  },

  setMotionRouteEndpoint: (route, endpoint, value) => {
    const routes = get().motionRoutes;
    set({
      motionPlaying: false,
      motionRoutes: { ...routes, [route]: { ...routes[route], [endpoint]: clampMotionEndpoint(route, value) } },
    });
  },

  setMotionPlaybackPosition: (t, progress, complete, runId) => {
    const state = get();
    if (!state.motionPlaying || state.motionRunId !== runId) return;
    applyMotionValue(t, complete, {
      motionProgress: Math.min(1, Math.max(0, progress)),
      ...(complete ? { motionPlaying: false } : {}),
    });
  },

  setLiveContour: (contour) => {
    const { spaceSeed } = get();
    set({
      spaceContour: contour,
      spaceView: buildSpaceView(contour, spaceSeed),
      spaceHasDrawn: true,
    });
  },

  finishSpaceGesture: (before, after) => {
    const { spaceSeed, spacePreset, spaceMetal, spacePast, spaceSeconds } = get();
    const changed = contoursDiffer(before, after);
    set({
      spaceContour: after,
      spaceView: buildSpaceView(after, spaceSeed),
      spacePreset: "custom",
      spaceHasDrawn: true,
      ...(changed
        ? {
            spacePast: pushSpacePast(spacePast, {
              contour: before,
              seed: spaceSeed,
              preset: spacePreset,
              metal: spaceMetal,
            }),
            spaceFuture: [],
          }
        : {}),
    });
    // Editing changes the contour identity to custom, not the processing identity.
    // A Metal-derived space therefore keeps its modal resonators until the user
    // explicitly chooses a non-Metal preset.
    applySpace(after, spaceSeed, spaceMetal, spaceSeconds);
  },

  applySpacePreset: (preset) => {
    const {
      spaceContour,
      spaceSeed,
      spacePreset,
      spaceMetal,
      spacePast,
      spaceSeconds,
    } = get();
    const next = generateSpaceContour(preset);
    const nextMetal = preset === "metal";
    if (!contoursDiffer(spaceContour, next) && spacePreset === preset) {
      set({ spacePreset: preset, spaceMetal: nextMetal, spaceHasDrawn: true });
      applySpace(next, spaceSeed, nextMetal, spaceSeconds);
      return;
    }
    set({
      spaceContour: next,
      spaceView: buildSpaceView(next, spaceSeed),
      spacePreset: preset,
      spaceMetal: nextMetal,
      spaceHasDrawn: true,
      spacePast: pushSpacePast(spacePast, {
        contour: spaceContour,
        seed: spaceSeed,
        preset: spacePreset,
        metal: spaceMetal,
      }),
      spaceFuture: [],
    });
    applySpace(next, spaceSeed, nextMetal, spaceSeconds);
  },

  scatterSpace: () => {
    const {
      spaceContour,
      spaceSeed,
      spacePreset,
      spaceMetal,
      spacePast,
      spaceSeconds,
    } = get();
    const seed = (spaceSeed + 0x9e3779b9) >>> 0 || 1;
    set({
      spaceSeed: seed,
      spaceView: buildSpaceView(spaceContour, seed),
      spaceHasDrawn: true,
      spacePast: pushSpacePast(spacePast, {
        contour: spaceContour,
        seed: spaceSeed,
        preset: spacePreset,
        metal: spaceMetal,
      }),
      spaceFuture: [],
    });
    applySpace(spaceContour, seed, spaceMetal, spaceSeconds);
  },

  setSpaceMix: (mix) => {
    stopForManualRoute("spaceMix");
    const next = Math.min(1, Math.max(0, mix));
    set({ spaceMix: next });
    synth.setSpaceMix(next);
    synth.unlock();
  },

  // Length is deliberately absent from SpaceSnap: it is a playback parameter,
  // not part of authored contour/seed/Metal history.
  setSpaceLength: (seconds) => {
    set({ spaceSeconds: clampSpaceSeconds(seconds) });
  },
  commitSpaceLength: (seconds) => {
    const spaceSeconds = clampSpaceSeconds(seconds);
    const { spaceContour, spaceSeed, spaceMetal } = get();
    set({ spaceSeconds });
    applySpace(spaceContour, spaceSeed, spaceMetal, spaceSeconds);
  },

  undo: () => {
    if (get().domain === "motion") {
      const { motionPast, motionPath, motionFuture } = get();
      const prev = motionPast[motionPast.length - 1];
      if (!prev) {
        set({ motionPlaying: false });
        return;
      }
      set({
        motionPath: cloneMotionPath(prev),
        motionPast: motionPast.slice(0, -1),
        motionFuture: [...motionFuture, cloneMotionPath(motionPath)],
        motionPlaying: false,
      });
      return;
    }
    if (get().domain === "drive") {
      const {
        drivePast,
        driveCurve,
        drivePreset,
        driveFuture,
        driveAmount,
        driveSafe,
      } = get();
      const prev = drivePast[drivePast.length - 1];
      if (!prev) return;
      set({
        driveCurve: cloneTransfer(prev.curve),
        drivePreset: prev.preset,
        drivePast: drivePast.slice(0, -1),
        driveFuture: [
          ...driveFuture,
          { curve: cloneTransfer(driveCurve), preset: drivePreset },
        ],
      });
      applyDrive(prev.curve, driveAmount, driveSafe);
      return;
    }
    if (get().domain === "chorus") {
      const { chorusPast, chorusCurve, chorusPreset, chorusFuture } = get();
      const prev = chorusPast[chorusPast.length - 1];
      if (!prev) return;
      set({
        chorusCurve: cloneChorusCurve(prev.curve),
        chorusPreset: prev.preset,
        chorusPast: chorusPast.slice(0, -1),
        chorusFuture: [
          ...chorusFuture,
          { curve: cloneChorusCurve(chorusCurve), preset: chorusPreset },
        ],
      });
      synth.setChorusCurve(prev.curve);
      return;
    }
    if (get().domain === "space") {
      const {
        spacePast,
        spaceContour,
        spaceSeed,
        spacePreset,
        spaceMetal,
        spaceFuture,
        spaceSeconds,
      } = get();
      const prev = spacePast[spacePast.length - 1];
      if (!prev) return;
      set({
        spaceContour: cloneContour(prev.contour),
        spaceSeed: prev.seed,
        spacePreset: prev.preset,
        spaceMetal: prev.metal,
        spaceView: buildSpaceView(prev.contour, prev.seed),
        spacePast: spacePast.slice(0, -1),
        spaceFuture: [
          ...spaceFuture,
          {
            contour: cloneContour(spaceContour),
            seed: spaceSeed,
            preset: spacePreset,
            metal: spaceMetal,
          },
        ],
      });
      applySpace(prev.contour, prev.seed, prev.metal, spaceSeconds);
      return;
    }
    const { past, samples, future } = get();
    const prev = past[past.length - 1];
    if (!prev) return;
    set({
      samples: cloneWave(prev),
      preset: "custom",
      morphLive: false,
      motionPlaying: false,
      past: past.slice(0, -1),
      future: [...future, cloneWave(samples)],
    });
    synth.setWaveform(prev, true);
  },
  redo: () => {
    if (get().domain === "motion") {
      const { motionFuture, motionPath, motionPast } = get();
      const next = motionFuture[motionFuture.length - 1];
      if (!next) {
        set({ motionPlaying: false });
        return;
      }
      set({
        motionPath: cloneMotionPath(next),
        motionFuture: motionFuture.slice(0, -1),
        motionPast: pushMotionPast(motionPast, motionPath),
        motionPlaying: false,
      });
      return;
    }
    if (get().domain === "drive") {
      const {
        driveFuture,
        driveCurve,
        drivePreset,
        drivePast,
        driveAmount,
        driveSafe,
      } = get();
      const next = driveFuture[driveFuture.length - 1];
      if (!next) return;
      set({
        driveCurve: cloneTransfer(next.curve),
        drivePreset: next.preset,
        driveFuture: driveFuture.slice(0, -1),
        drivePast: pushDrivePast(drivePast, {
          curve: driveCurve,
          preset: drivePreset,
        }),
      });
      applyDrive(next.curve, driveAmount, driveSafe);
      return;
    }
    if (get().domain === "chorus") {
      const { chorusFuture, chorusCurve, chorusPreset, chorusPast } = get();
      const next = chorusFuture[chorusFuture.length - 1];
      if (!next) return;
      set({
        chorusCurve: cloneChorusCurve(next.curve),
        chorusPreset: next.preset,
        chorusFuture: chorusFuture.slice(0, -1),
        chorusPast: pushChorusPast(chorusPast, {
          curve: chorusCurve,
          preset: chorusPreset,
        }),
      });
      synth.setChorusCurve(next.curve);
      return;
    }
    if (get().domain === "space") {
      const {
        spaceFuture,
        spaceContour,
        spaceSeed,
        spacePreset,
        spaceMetal,
        spacePast,
        spaceSeconds,
      } = get();
      const next = spaceFuture[spaceFuture.length - 1];
      if (!next) return;
      set({
        spaceContour: cloneContour(next.contour),
        spaceSeed: next.seed,
        spacePreset: next.preset,
        spaceMetal: next.metal,
        spaceView: buildSpaceView(next.contour, next.seed),
        spaceFuture: spaceFuture.slice(0, -1),
        spacePast: pushSpacePast(spacePast, {
          contour: spaceContour,
          seed: spaceSeed,
          preset: spacePreset,
          metal: spaceMetal,
        }),
      });
      applySpace(next.contour, next.seed, next.metal, spaceSeconds);
      return;
    }
    const { future, samples, past } = get();
    const next = future[future.length - 1];
    if (!next) return;
    set({
      samples: cloneWave(next),
      preset: "custom",
      morphLive: false,
      motionPlaying: false,
      future: future.slice(0, -1),
      past: pushPast(past, samples),
    });
    synth.setWaveform(next, true);
  },

  setParam: (key, value) => {
    set({ [key]: value } as Partial<SynthState>);
    synth.setParams({ [key]: value });
    synth.unlock();
  },
  setOctave: (octave) => {
    const next = Math.min(3, Math.max(-2, octave));
    set({ octave: next });
  },
  setActiveNotes: (notes) => set({ activeNotes: notes }),
  setAudioReady: (ready) => set({ audioReady: ready }),
  markDrawn: () => set({ hasDrawn: true }),
  markSpaceDrawn: () => set({ spaceHasDrawn: true }),
  replaceSavedSession: (patch) => {
    synth.allNotesOff();
    const slotA = patch.slotA ? cloneWave(patch.slotA) : null;
    const slotB = patch.slotB ? cloneWave(patch.slotB) : null;
    set({
      domain: patch.domain,
      samples: cloneWave(patch.samples),
      preset: patch.preset,
      hasDrawn: patch.hasDrawn,
      slotA,
      slotB,
      morph: patch.morph,
      morphLive: patch.morphLive,
      attack: patch.attack,
      release: patch.release,
      cutoff: patch.cutoff,
      volume: patch.volume,
      trimDb: patch.trimDb,
      octave: patch.octave,
      driveCurve: cloneTransfer(patch.driveCurve),
      drivePreset: patch.drivePreset,
      driveAmount: patch.driveAmount,
      driveSafe: patch.driveSafe,
      driveHasDrawn: patch.driveHasDrawn,
      chorusCurve: cloneChorusCurve(patch.chorusCurve),
      chorusPreset: patch.chorusPreset,
      chorusPeriod: patch.chorusPeriod,
      chorusMix: patch.chorusMix,
      spaceContour: cloneContour(patch.spaceContour),
      spaceSeed: patch.spaceSeed,
      spacePreset: patch.spacePreset,
      spaceMetal: patch.spaceMetal,
      spaceMix: patch.spaceMix,
      spaceSeconds: patch.spaceSeconds,
      spaceHasDrawn: patch.spaceHasDrawn,
      spaceView: buildSpaceView(patch.spaceContour, patch.spaceSeed),
      motionPath: cloneMotionPath(patch.motionPath),
      motionBpm: patch.motionBpm,
      motionBeats: patch.motionBeats,
      motionMode: patch.motionMode,
      motionRoutes: {
        cycle: { ...patch.motionRoutes.cycle },
        driveAmount: { ...patch.motionRoutes.driveAmount },
        chorusMix: { ...patch.motionRoutes.chorusMix },
        spaceMix: { ...patch.motionRoutes.spaceMix },
      },
      motionPlaying: false,
      motionProgress: 0,
      motionRunId: get().motionRunId + 1,
      activeNotes: [],
      past: [],
      future: [],
      motionPast: [],
      motionFuture: [],
      drivePast: [],
      driveFuture: [],
      chorusPast: [],
      chorusFuture: [],
      spacePast: [],
      spaceFuture: [],
    });
    synth.setParams({
      attack: patch.attack,
      release: patch.release,
      volume: patch.volume,
      trimDb: patch.trimDb,
      cutoff: patch.cutoff,
    });
    synth.setDriveState(patch.driveCurve, patch.driveAmount, patch.driveSafe);
    synth.setChorusCurve(patch.chorusCurve);
    synth.setChorusPeriod(patch.chorusPeriod);
    synth.setChorusMix(patch.chorusMix);
    synth.setSpace(patch.spaceContour, patch.spaceSeed, patch.spaceMetal, patch.spaceSeconds);
    synth.setSpaceMix(patch.spaceMix);
    if (patch.morphLive && slotA && slotB) synth.setCycleMorph(slotA, slotB, patch.morph);
    else synth.setWaveform(patch.samples, true);
  },
  };
});

synth.setWaveform(cloneWave(initialSamples), true);
synth.setDriveState(
  cloneTransfer(initialDriveCurve),
  DRIVE_DEFAULT_AMOUNT,
  DRIVE_DEFAULT_SAFE,
);
synth.setChorusCurve(cloneChorusCurve(initialChorusCurve));
synth.setChorusPeriod(CHORUS_DEFAULT_PERIOD);
synth.setChorusMix(0);
synth.setSpace(cloneContour(initialContour), initialSeed, false, SPACE_DEFAULT_SECONDS);
synth.setSpaceMix(INITIAL_SPACE_MIX);
