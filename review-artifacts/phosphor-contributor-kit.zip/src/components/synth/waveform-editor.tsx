import { useCallback, useEffect, useRef, useState } from "react";
import {
  readCanvasTreatmentTokens,
  type CanvasTreatmentTokens,
} from "@/lib/presentation/canvas-tokens";
import { useTreatment } from "@/lib/presentation/treatment";
import { editorPlotInsets } from "@/lib/presentation/editor-layout";
import { useSynthStore, type EditorDomain } from "@/lib/synth/store";
import { WAVE_SIZE } from "@/lib/synth/waveform";
import { cycleGestureIndex, cycleSampleIndex, paintCycleSpan } from "@/lib/synth/cycle-drawing";
import {
  SPACE_SIZE,
  buildSpaceView,
  sampleContour,
} from "@/lib/synth/space";
import {
  DRIVE_SIZE,
  buildAppliedDriveCurve,
  effectiveDriveAmount,
} from "@/lib/synth/drive";
import {
  CHORUS_MAX_MS,
  CHORUS_MIN_MS,
  CHORUS_SIZE,
  chorusDelayMs,
  phaseShiftCurve,
} from "@/lib/synth/chorus";
import { CURVE_UPDATE_INTERVAL_MS, synth } from "@/lib/synth/engine";
import { EditorTabs } from "./editor-tabs";

type DrawingDomain = Exclude<EditorDomain, "motion">;

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function signedLevel(value: number) {
  const normalized = Math.abs(value) < 0.005 ? 0 : value;
  return `${normalized < 0 ? "−" : "+"}${Math.abs(normalized).toFixed(2)}`;
}

function drawPlotGrid(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  tokens: CanvasTreatmentTokens,
) {
  ctx.lineWidth = 1;
  ctx.strokeStyle = tokens.gridMinor;
  ctx.beginPath();
  for (let g = 1; g < 16; g += 2) {
    const gx = x + (g / 16) * width;
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + height);
  }
  for (let g = 1; g < 8; g += 2) {
    const gy = y + (g / 8) * height;
    ctx.moveTo(x, gy);
    ctx.lineTo(x + width, gy);
  }
  ctx.stroke();

  ctx.strokeStyle = tokens.gridMajor;
  ctx.beginPath();
  for (let g = 0; g <= 8; g++) {
    const gx = x + (g / 8) * width;
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + height);
  }
  for (let g = 0; g <= 4; g++) {
    const gy = y + (g / 4) * height;
    ctx.moveTo(x, gy);
    ctx.lineTo(x + width, gy);
  }
  ctx.stroke();
}

function wrapSample(wave: number[], i: number) {
  const n = wave.length;
  if (n === 0) return 0;
  return wave[((i % n) + n) % n] ?? 0;
}

export function WaveformEditor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [driveInputRange, setDriveInputRange] = useState({ min: 0, max: 0 });
  const domain = useSynthStore((s) => s.domain);
  const { treatment } = useTreatment();
  const samples = useSynthStore((s) => s.samples);
  const driveCurve = useSynthStore((s) => s.driveCurve);
  const driveAmount = useSynthStore((s) => s.driveAmount);
  const driveSafe = useSynthStore((s) => s.driveSafe);
  const chorusCurve = useSynthStore((s) => s.chorusCurve);
  const spaceContour = useSynthStore((s) => s.spaceContour);
  const spaceView = useSynthStore((s) => s.spaceView);
  const spaceSeconds = useSynthStore((s) => s.spaceSeconds);
  const hasDrawn = useSynthStore((s) => s.hasDrawn);
  const driveHasDrawn = useSynthStore((s) => s.driveHasDrawn);
  const spaceHasDrawn = useSynthStore((s) => s.spaceHasDrawn);
  const morphLive = useSynthStore((s) => s.morphLive);
  const morphArmed = useSynthStore((s) => Boolean(s.slotA && s.slotB));
  const setLiveSamples = useSynthStore((s) => s.setLiveSamples);
  const finishGesture = useSynthStore((s) => s.finishGesture);
  const setLiveDrive = useSynthStore((s) => s.setLiveDrive);
  const finishDriveGesture = useSynthStore((s) => s.finishDriveGesture);
  const setLiveChorus = useSynthStore((s) => s.setLiveChorus);
  const finishChorusGesture = useSynthStore((s) => s.finishChorusGesture);
  const setLiveContour = useSynthStore((s) => s.setLiveContour);
  const finishSpaceGesture = useSynthStore((s) => s.finishSpaceGesture);
  const markDrawn = useSynthStore((s) => s.markDrawn);
  const markSpaceDrawn = useSynthStore((s) => s.markSpaceDrawn);

  const liveRef = useRef<number[]>(samples);
  const driveRef = useRef<number[]>(driveCurve);
  const driveAmountRef = useRef(driveAmount);
  const driveSafeRef = useRef(driveSafe);
  const chorusRef = useRef<number[]>(chorusCurve);
  const contourRef = useRef<number[]>(spaceContour);
  const viewRef = useRef<number[]>(spaceView);
  const secondsRef = useRef(spaceSeconds);
  const domainRef = useRef(domain);
  const drawingRef = useRef(false);
  const gestureDomainRef = useRef<DrawingDomain | null>(null);
  const pointerIdRef = useRef<number | null>(null);
  const lastIndexRef = useRef<number | null>(null);
  const originRef = useRef<number[] | null>(null);

  domainRef.current = domain;
  driveAmountRef.current = driveAmount;
  driveSafeRef.current = driveSafe;
  if (!drawingRef.current) {
    liveRef.current = samples;
    driveRef.current = driveCurve;
    chorusRef.current = chorusCurve;
    contourRef.current = spaceContour;
    viewRef.current = spaceView;
    secondsRef.current = spaceSeconds;
  }

  const paint = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (w === 0 || h === 0) return;
    const pw = Math.floor(w * dpr);
    const ph = Math.floor(h * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const tokens = readCanvasTreatmentTokens(canvas);

    ctx.fillStyle = tokens.plot;
    ctx.fillRect(0, 0, w, h);

    const { x: padX, y: padY } = editorPlotInsets(w, h);
    const innerW = w - padX * 2;
    const innerH = h - padY * 2;
    const yAt = (v: number) => padY + (0.5 - v * 0.5) * innerH;
    const yEnergy = (e: number) => padY + (1 - clamp(e, 0, 1)) * innerH;
    const space = domainRef.current === "space";
    const drive = domainRef.current === "drive";
    const chorus = domainRef.current === "chorus";

    drawPlotGrid(ctx, padX, padY, innerW, innerH, tokens);

    if (space) {
      const contour = contourRef.current;
      const view = viewRef.current;
      const cn = contour.length || SPACE_SIZE;
      const vn = view.length || SPACE_SIZE;
      const xLin = (i: number, n: number) => padX + (i / Math.max(1, n - 1)) * innerW;

      ctx.strokeStyle = tokens.axis;
      ctx.beginPath();
      ctx.moveTo(padX, padY + innerH);
      ctx.lineTo(padX + innerW, padY + innerH);
      ctx.stroke();

      ctx.save();
      ctx.globalAlpha = tokens.spaceFillAlpha;
      ctx.fillStyle = tokens.spaceFill;
      ctx.beginPath();
      ctx.moveTo(padX, padY + innerH);
      for (let i = 0; i < cn; i++) {
        ctx.lineTo(xLin(i, cn), yEnergy(contour[i] ?? 0));
      }
      ctx.lineTo(padX + innerW, padY + innerH);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = tokens.microstructureAlpha;
      ctx.strokeStyle = tokens.traceSecondary;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < vn; i++) {
        const t = i / Math.max(1, vn - 1);
        const e = sampleContour(contour, t);
        const ir = view[i] ?? 0;
        const span = e * innerH;
        const yTop = padY + innerH - span;
        const y =
          span < 0.5
            ? padY + innerH
            : yTop + clamp((e - ir) / (2 * Math.max(e, 1e-6)), 0, 1) * span;
        const x = xLin(i, vn);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.strokeStyle = tokens.tracePrimary;
      ctx.lineWidth = tokens.traceWidth;
      ctx.shadowColor = tokens.tracePrimary;
      ctx.shadowBlur = tokens.traceGlow;
      ctx.beginPath();
      for (let i = 0; i < cn; i++) {
        const x = xLin(i, cn);
        const y = yEnergy(contour[i] ?? 0);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();

      ctx.fillStyle = tokens.annotation;
      ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText("1", 14, yEnergy(1));
      ctx.fillText("0", 14, yEnergy(0));
      ctx.textBaseline = "top";
      ctx.fillText("0 s", padX, padY + innerH + 8);
      ctx.textAlign = "right";
      ctx.fillText(`${secondsRef.current.toFixed(1)} s`, padX + innerW, padY + innerH + 8);
    } else if (drive) {
      const curve = driveRef.current;
      const n = curve.length || DRIVE_SIZE;
      const xAt = (i: number) => padX + (i / Math.max(1, n - 1)) * innerW;
      const appliedAmount = effectiveDriveAmount(
        driveAmountRef.current,
        driveSafeRef.current,
      );

      ctx.strokeStyle = tokens.axis;
      ctx.beginPath();
      ctx.moveTo(padX, yAt(0));
      ctx.lineTo(padX + innerW, yAt(0));
      ctx.moveTo(padX + innerW * 0.5, padY);
      ctx.lineTo(padX + innerW * 0.5, padY + innerH);
      ctx.stroke();

      ctx.save();
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = tokens.annotation;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 5]);
      ctx.beginPath();
      ctx.moveTo(padX, yAt(-1));
      ctx.lineTo(padX + innerW, yAt(1));
      ctx.stroke();
      ctx.restore();

      const strokeTransfer = (
        values: ArrayLike<number>,
        color: string,
        width: number,
        dashed: boolean,
        glow: number,
      ) => {
        ctx.save();
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.shadowColor = color;
        ctx.shadowBlur = glow;
        if (dashed) ctx.setLineDash([7, 4]);
        ctx.beginPath();
        for (let i = 0; i < values.length; i++) {
          const x = xAt(i);
          const y = yAt(values[i] ?? 0);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.restore();
      };

      if (appliedAmount < 1) {
        const applied = buildAppliedDriveCurve(curve, appliedAmount, n);
        // Authored stays visibly editable; applied carries equal visual weight
        // and a solid treatment so it cannot read as decorative ghosting.
        strokeTransfer(
          curve,
          tokens.traceSecondary,
          Math.max(1.6, tokens.traceWidth),
          true,
          0,
        );
        strokeTransfer(
          applied,
          tokens.tracePrimary,
          tokens.traceWidth + 0.65,
          false,
          tokens.traceGlow,
        );
      } else {
        strokeTransfer(
          curve,
          tokens.tracePrimary,
          tokens.traceWidth,
          false,
          tokens.traceGlow,
        );
      }

      ctx.fillStyle = tokens.annotation;
      ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText("+1", 8, yAt(1));
      ctx.fillText("0", 12, yAt(0));
      ctx.fillText("−1", 8, yAt(-1));
      ctx.textBaseline = "top";
      ctx.fillText("−1 in", padX, padY + innerH + 8);
      ctx.textAlign = "center";
      ctx.fillText("0", padX + innerW * 0.5, padY + innerH + 8);
      ctx.textAlign = "right";
      ctx.fillText("+1 in", padX + innerW, padY + innerH + 8);

      ctx.font = "10px 'IBM Plex Mono', ui-monospace, monospace";
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      if (appliedAmount < 1) {
        ctx.fillStyle = tokens.traceSecondary;
        ctx.fillText("AUTHORED — —", padX + 8, padY + 8);
        ctx.fillStyle = tokens.tracePrimary;
        ctx.fillText(
          `APPLIED ${Math.round(appliedAmount * 100)}%`,
          padX + 8,
          padY + 23,
        );
      } else {
        ctx.fillStyle = tokens.tracePrimary;
        ctx.fillText("AUTHORED = APPLIED", padX + 8, padY + 8);
      }
    } else if (chorus) {
      const curve = chorusRef.current;
      const n = curve.length || CHORUS_SIZE;
      const xLin = (i: number) => padX + (i / Math.max(1, n - 1)) * innerW;
      const yDelay = (v: number) =>
        padY +
        (1 -
          (chorusDelayMs(v) - CHORUS_MIN_MS) /
            (CHORUS_MAX_MS - CHORUS_MIN_MS)) *
          innerH;

      ctx.strokeStyle = tokens.axis;
      ctx.beginPath();
      ctx.moveTo(padX, padY);
      ctx.lineTo(padX, padY + innerH);
      ctx.lineTo(padX + innerW, padY + innerH);
      ctx.stroke();

      ctx.fillStyle = tokens.annotation;
      ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
      ctx.textBaseline = "middle";
      ctx.textAlign = "left";
      ctx.fillText(`${CHORUS_MAX_MS} ms`, 8, padY);
      ctx.fillText(`${CHORUS_MIN_MS} ms`, 8, padY + innerH);
      ctx.textBaseline = "top";
      ctx.textAlign = "right";
      ctx.fillText("0°", padX, padY + innerH + 8);
      ctx.fillText("360°", padX + innerW, padY + innerH + 8);

      const stroke = (values: number[], color: string, alpha: number, width: number) => {
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.lineJoin = "round";
        ctx.beginPath();
        values.forEach((v, i) => {
          const x = xLin(i);
          const y = yDelay(v);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.restore();
      };
      stroke(curve, tokens.tracePrimary, 1, tokens.traceWidth);
      stroke(phaseShiftCurve(curve), tokens.traceSecondary, 0.35, 1);
      ctx.textBaseline = "middle";
      ctx.fillStyle = tokens.annotation;
      ctx.textAlign = "left";
      ctx.fillText("authored", padX + 8, padY + 12);
      ctx.fillStyle = tokens.traceSecondary;
      ctx.fillText("derived stereo", padX + 8, padY + 27);
    } else {
      ctx.strokeStyle = tokens.axis;
      ctx.beginPath();
      ctx.moveTo(padX, yAt(0));
      ctx.lineTo(padX + innerW, yAt(0));
      ctx.stroke();

      const wave = liveRef.current;
      const n = wave.length || WAVE_SIZE;
      const ghost = Math.max(8, Math.round(n * 0.08));
      const xAt = (i: number, count: number) => padX + (i / count) * innerW;

      const strokeWave = (
        from: number,
        to: number,
        color: string,
        alpha: number,
        width: number,
        glow: boolean,
      ) => {
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.shadowColor = glow ? color : "transparent";
        ctx.shadowBlur = glow ? tokens.traceGlow : 0;
        ctx.beginPath();
        for (let i = from; i <= to; i++) {
          const x = xAt(i, n);
          const y = yAt(wrapSample(wave, i));
          if (i === from) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.restore();
      };

      strokeWave(
        -ghost,
        0,
        tokens.traceGhost,
        tokens.ghostAlpha,
        tokens.ghostWidth,
        false,
      );
      strokeWave(
        n,
        n + ghost,
        tokens.traceGhost,
        tokens.ghostAlpha,
        tokens.ghostWidth,
        false,
      );
      strokeWave(0, n, tokens.tracePrimary, 1, tokens.traceWidth, true);

      ctx.fillStyle = tokens.tracePrimary;
      ctx.beginPath();
      ctx.arc(xAt(0, n), yAt(wrapSample(wave, 0)), 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(xAt(n, n), yAt(wrapSample(wave, 0)), 2.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = tokens.annotation;
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 3]);
      ctx.beginPath();
      ctx.moveTo(padX, padY);
      ctx.lineTo(padX, padY + innerH);
      ctx.moveTo(padX + innerW, padY);
      ctx.lineTo(padX + innerW, padY + innerH);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = tokens.annotation;
      ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText("+1", 8, yAt(1));
      ctx.fillText("0", 12, yAt(0));
      ctx.fillText("−1", 8, yAt(-1));
    }
  }, []);

  useEffect(() => {
    liveRef.current = samples;
    driveRef.current = driveCurve;
    driveAmountRef.current = driveAmount;
    driveSafeRef.current = driveSafe;
    chorusRef.current = chorusCurve;
    contourRef.current = spaceContour;
    viewRef.current = spaceView;
    secondsRef.current = spaceSeconds;
    domainRef.current = domain;
    paint();
  }, [
    samples,
    driveCurve,
    driveAmount,
    driveSafe,
    chorusCurve,
    spaceContour,
    spaceView,
    spaceSeconds,
    domain,
    paint,
  ]);

  useEffect(() => {
    paint();
  }, [treatment, paint]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ro = new ResizeObserver(() => paint());
    ro.observe(canvas);
    paint();
    return () => ro.disconnect();
  }, [paint]);

  useEffect(() => {
    if (domain !== "drive") return;
    const sample = () => {
      const next = synth.measureDriveInputRange();
      setDriveInputRange((current) =>
        Math.abs(current.min - next.min) < 0.005 &&
        Math.abs(current.max - next.max) < 0.005
          ? current
          : next,
      );
    };
    sample();
    const timer = window.setInterval(sample, CURVE_UPDATE_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [domain]);

  const eventToHit = (
    e: React.PointerEvent<HTMLCanvasElement>,
    targetDomain: DrawingDomain,
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const { x: padX, y: padY } = editorPlotInsets(rect.width, rect.height);
    const innerW = Math.max(1, rect.width - padX * 2);
    const innerH = Math.max(1, rect.height - padY * 2);
    const x = clamp((e.clientX - rect.left - padX) / innerW, 0, 1);
    const y = clamp((e.clientY - rect.top - padY) / innerH, 0, 1);
    if (targetDomain === "space") {
      const index = clamp(Math.round(x * (SPACE_SIZE - 1)), 0, SPACE_SIZE - 1);
      return { index, value: clamp(1 - y, 0, 1), size: SPACE_SIZE };
    }
    if (targetDomain === "drive") {
      const index = clamp(Math.round(x * (DRIVE_SIZE - 1)), 0, DRIVE_SIZE - 1);
      return { index, value: clamp(1 - 2 * y, -1, 1), size: DRIVE_SIZE };
    }
    if (targetDomain === "chorus") {
      const index = clamp(Math.round(x * (CHORUS_SIZE - 1)), 0, CHORUS_SIZE - 1);
      return { index, value: clamp(1 - 2 * y, -1, 1), size: CHORUS_SIZE };
    }
    const index = cycleGestureIndex(x, WAVE_SIZE);
    const value = clamp(1 - 2 * y, -1, 1);
    return { index, value, size: WAVE_SIZE };
  };

  const paintSpan = (from: number, to: number, v0: number, v1: number, wave: number[]) => {
    const a = Math.min(from, to);
    const b = Math.max(from, to);
    const span = Math.max(1, b - a);
    for (let i = a; i <= b; i++) {
      const u = (i - a) / span;
      const startV = from <= to ? v0 : v1;
      const endV = from <= to ? v1 : v0;
      wave[i] = startV + (endV - startV) * u;
    }
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (drawingRef.current || domainRef.current === "motion") return;
    const gestureDomain = domainRef.current;
    const hit = eventToHit(e, gestureDomain);
    if (!hit) return;
    synth.unlock();
    e.currentTarget.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    gestureDomainRef.current = gestureDomain;
    pointerIdRef.current = e.pointerId;
    const space = gestureDomain === "space";
    const drive = gestureDomain === "drive";
    const chorus = gestureDomain === "chorus";
    if (space) markSpaceDrawn();
    else if (!drive && !chorus) markDrawn();
    const source = space
      ? contourRef.current
      : drive
        ? driveRef.current
        : chorus
          ? chorusRef.current
          : liveRef.current;
    originRef.current = source.slice();
    const wave = source.slice();
    wave[gestureDomain === "cycle" ? cycleSampleIndex(hit.index, wave.length) : hit.index] = hit.value;
    lastIndexRef.current = hit.index;
    if (space) {
      contourRef.current = wave;
      viewRef.current = buildSpaceView(wave, useSynthStore.getState().spaceSeed);
      setLiveContour(wave);
    } else if (drive) {
      driveRef.current = wave;
      setLiveDrive(wave);
    } else if (chorus) {
      chorusRef.current = wave;
      setLiveChorus(wave);
    } else {
      liveRef.current = wave;
      setLiveSamples(wave, false);
    }
    paint();
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || pointerIdRef.current !== e.pointerId) return;
    const gestureDomain = gestureDomainRef.current;
    if (!gestureDomain) return;
    const hit = eventToHit(e, gestureDomain);
    if (!hit) return;
    const space = gestureDomain === "space";
    const drive = gestureDomain === "drive";
    const chorus = gestureDomain === "chorus";
    const wave = (
      space
        ? contourRef.current
        : drive
          ? driveRef.current
          : chorus
            ? chorusRef.current
            : liveRef.current
    ).slice();
    const last = lastIndexRef.current;
    if (gestureDomain === "cycle") {
      paintCycleSpan(wave, last ?? hit.index, hit.index, hit.value);
    } else if (last === null || last === hit.index) {
      wave[hit.index] = hit.value;
    } else {
      paintSpan(last, hit.index, wave[last] ?? hit.value, hit.value, wave);
    }
    lastIndexRef.current = hit.index;
    if (space) {
      contourRef.current = wave;
      viewRef.current = buildSpaceView(wave, useSynthStore.getState().spaceSeed);
      setLiveContour(wave);
    } else if (drive) {
      driveRef.current = wave;
      setLiveDrive(wave);
    } else if (chorus) {
      chorusRef.current = wave;
      setLiveChorus(wave);
    } else {
      liveRef.current = wave;
      setLiveSamples(wave, false);
    }
    paint();
  };

  const finishActiveGesture = useCallback(() => {
    if (!drawingRef.current) return;
    const gestureDomain = gestureDomainRef.current;
    drawingRef.current = false;
    gestureDomainRef.current = null;
    pointerIdRef.current = null;
    lastIndexRef.current = null;
    if (!gestureDomain) return;
    const space = gestureDomain === "space";
    const drive = gestureDomain === "drive";
    const chorus = gestureDomain === "chorus";
    const current = space
      ? contourRef.current
      : drive
        ? driveRef.current
        : chorus
          ? chorusRef.current
          : liveRef.current;
    const origin = originRef.current ?? current;
    originRef.current = null;
    if (space) finishSpaceGesture(origin, contourRef.current);
    else if (drive) finishDriveGesture(origin, driveRef.current);
    else if (chorus) finishChorusGesture(origin, chorusRef.current);
    else finishGesture(origin, liveRef.current);
  }, [
    finishChorusGesture,
    finishDriveGesture,
    finishGesture,
    finishSpaceGesture,
  ]);

  const endDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || pointerIdRef.current !== e.pointerId) return;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
    finishActiveGesture();
  };

  useEffect(() => () => finishActiveGesture(), [finishActiveGesture]);

  const space = domain === "space";
  const drive = domain === "drive";
  const chorus = domain === "chorus";
  const appliedDriveAmount = effectiveDriveAmount(driveAmount, driveSafe);
  const appliedDrivePercent = Math.round(appliedDriveAmount * 100);
  const title = space
    ? "Space · impulse response"
    : drive
      ? "Drive · authored + applied transfer"
      : chorus
        ? "Chorus · delay-time cycle"
        : `Oscillator · ${morphArmed && !morphLive ? "custom" : "1 cycle"}`;
  const showHint = chorus ? false : space ? !spaceHasDrawn : drive ? !driveHasDrawn : !hasDrawn;

  return (
    <div className="phosphor-editor rounded-xl bg-plot shadow-border">
      <div className="phosphor-editor-head">
        <EditorTabs />
        <div className="phosphor-editor-description">
          <span className="phosphor-editor-title">
            {title}
          </span>
        <span className="phosphor-editor-status-detail">
          {space
            ? `0 s → ${spaceSeconds.toFixed(1)} s`
            : drive
              ? <>
                  <span className="hidden sm:inline">
                    {driveSafe ? "SAFE" : "SAFE OFF"} · {appliedDrivePercent}% ·{" "}
                  </span>
                  IN {signedLevel(driveInputRange.min)}…{signedLevel(driveInputRange.max)}
                </>
              : chorus
                ? `${CHORUS_MIN_MS} ↔ ${CHORUS_MAX_MS} ms`
                : "−1 ↔ +1"}
        </span>
        </div>
      </div>
      <canvas
        ref={canvasRef}
        className="phosphor-editor-canvas touch-none cursor-crosshair"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDraw}
        onPointerCancel={endDraw}
        aria-label={
          space
            ? "Draw space impulse response"
            : drive
              ? appliedDriveAmount < 1
                ? `Draw authored drive transfer function. Dashed trace is authored; solid trace shows ${appliedDrivePercent}% applied. Safe mode ${driveSafe ? "on" : "off"}.`
                : "Draw authored drive transfer function. The authored transfer is fully applied; Safe mode off."
              : chorus
                ? "Draw chorus delay-time modulation"
                : "Draw oscillator waveform"
        }
      />
        <p className="phosphor-editor-caption" aria-live="polite">
          {showHint ? space
            ? "Drag to draw this response"
            : drive
              ? "Drag to shape input into output"
              : "Drag to redraw this cycle"
            : chorus ? "Bright: authored delay · faint: derived stereo"
            : "Drag to edit · Esc to stop sound"}
        </p>
    </div>
  );
}
